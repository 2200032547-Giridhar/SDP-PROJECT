class BankAccount:
    def __init__(self, accountNumber, name, balance):
        self.accountNumber = accountNumber
        self.name = name
        self.balance = balance

    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            print(f"Deposit of RS.{amount} Successfully.")
        else:
            print("Invalid Deposit Amount")

    def withdrawal(self, amount):
        if 0 < amount <= self.balance:
            self.balance -= amount
            print(f"Withdrawal of RS.{amount} Successfully.")
        else:
            print("Invalid To Withdraw a Amount")

    def bank_fees(self):
        fees = 0.05 * self.balance
        self.balance -= fees
        print(f"Bank charges of RS.{fees} applied")

    def display(self):
        print(f"AccountNumber : {self.accountNumber}")
        print(f"Account Holder Name : {self.name}")
        print(f"Balance RS.{self.balance}")


account1 = BankAccount(accountNumber=123456789, name="Sanjay", balance=10000)

account1.display()

account1.deposit(5000)
account1.withdrawal(2000)
account1.bank_fees()

account1.display()
