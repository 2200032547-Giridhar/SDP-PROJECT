a=complex(input("Enter a number : "))
b=complex(input("Enter a number : "))
c=a+b
print("Add Complex of Two Numbers : ",c)
d=float(input("Enter a number"))
e=float(input("Enter a number"))
f=d+e
print("Add Float of Two Numbers : ",f)
g=int(input("Enter a number"))
h=int(input("Enter a number"))
i=g+h
print("Add integer of Two Number : ",i)