n=int(input("Enter a Number : "))
m=float(n)
print("The Given Value of float value : ",m)