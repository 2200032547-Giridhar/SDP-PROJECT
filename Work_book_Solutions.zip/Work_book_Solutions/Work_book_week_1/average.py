#program 5
numbers=[]
n=int(input("Enter a Number : "))
for i in range(1,n+1):
        m=int(input("Enter a numbers : "))
        numbers.append(m)
avg=sum(numbers)/n
print("Average of the Given Numbers : ",avg)