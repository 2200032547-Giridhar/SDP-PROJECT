n=input("Enter a element  : ")
m=int(input("Enter a number : "))

o=int(n)
print(o+m)