binary_numbers = input("Enter a sequence of comma separated 4 digit binary numbers: ")
binary_list = binary_numbers.split(',')
divisible_by_5 = [int(binary, 2) for binary in binary_list if int(binary, 2) % 5 == 0]
print(','.join(map(str, divisible_by_5)))