n=int(input())
i=1
while(i<=7):
    print(n,"*",i,"=",n*i)
    i+=1